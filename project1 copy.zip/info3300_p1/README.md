# info3300_p1
A static data visualization 
